These are the images used in my Home Assistant + OpenAI video:
👉 https://youtu.be/i4QgnzGsVM8

How to use:
1. Choose one of the fridge photos from the variation folders.
2. Copy the file named fridge-photo.jpg into this folder on your Home Assistant server:
\\<Home-Assistant-IP>\config\www\fridge
3. Overwrite the existing file when prompted
4. Refresh your Home Assistant dashboard — the new fridge photo will appear